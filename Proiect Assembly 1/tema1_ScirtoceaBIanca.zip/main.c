#include <stdio.h>
#include "structs.h"
#include <stdlib.h>
#include <string.h>
void get_operations(void **operations);

void Citire(sensor *sen, int nr, FILE *fin)
{
	/*se incepe citirea informatiilor despre senzori din fisier*/
	for (int i = 0; i < nr; i++) {
		/*se citeste tipul de senzor*/
		fread(&sen[i].sensor_type, sizeof(sen->sensor_type), 1, fin);

		/*in functie de tipul senzorului se citesc datele sale*/
		if (sen[i].sensor_type == 1) {
		/*se aloca memorie dinamic pentru o
		 variabila de tip PMU si se verifica alocarea*/
		power_management_unit *pmu;
		pmu = (power_management_unit *)malloc(sizeof(power_management_unit));
		if (!pmu)
			return;

		/*se citesc datele specifice structurii PMU*/
		fread(&pmu->voltage, sizeof(pmu->voltage), 1, fin);
		fread(&pmu->current, sizeof(pmu->current), 1, fin);
		fread(&pmu->power_consumption, sizeof(pmu->power_consumption), 1, fin);
		fread(&pmu->energy_regen, sizeof(pmu->energy_regen), 1, fin);
		fread(&pmu->energy_storage, sizeof(pmu->energy_storage), 1, fin);

		/*se face cast la void * noii variabile alocate,
		 dupa atribuindu-se lui sensor_data*/
		sen[i].sensor_data = (void *)pmu;
		}

		if (sen[i].sensor_type == 0) {

		/*se aloca memorie dinamic pentru o
		 variabila de tip TIRE si se verifica alocarea*/
		tire_sensor *tire = (tire_sensor *)malloc(sizeof(tire_sensor));
		if (!tire)
			return;

		/*se citesc datele specifice structurii TIRE*/
		fread(&tire->pressure, sizeof(tire->pressure), 1, fin);
		fread(&tire->temperature, sizeof(tire->temperature), 1, fin);
		fread(&tire->wear_level, sizeof(tire->wear_level), 1, fin);
		fread(&tire->performace_score, sizeof(tire->performace_score), 1, fin);

		/*se face cast la void * noii variabile alocate,
		 dupa atribuindu-se lui sensor_data*/
		sen[i].sensor_data = (void *)tire;
		}

		/*se citeste tot din fisier numarul de operatii
		 ale senzorului respectiv*/
		fread(&sen[i].nr_operations, sizeof(sen[i].nr_operations), 1, fin);
		int nop = sen[i].nr_operations;

		/*se aloca memorie pentru vectorul cu operatiile
		 senzorului si se verifica alocarea*/
		sen[i].operations_idxs = (int *)malloc(nop * sizeof(int));
		if (!sen[i].operations_idxs)
			return;
		/*se parcurge vectorul si se citesc din fisier
		 indexurile respective ale operatiilor*/
		for (int j = 0; j < nop; j++)
			fread(&(sen[i].operations_idxs[j]), 1, sizeof(int), fin);
	}
}

void SortarePrioritati(sensor *sen, int nr, int ok)
{
	/*se sorteaza prin metoda bubble sort vectorul
	 se senzori in functie de prioritati*/
	while (ok == 0) {
		/*se presupune ca vectorul este sortat*/
		ok = 1;

		/*se parcurge vectorul de senzori*/
		for (int j = 0; j < nr - 1; j++) {
			/*daca se gaseste un vector de tip TIRE inaintea
			unui vector de tip PMU se interschimba intre
			ele prin intermediul unei variabile
			de tip sensor auxiliare*/
			if (sen[j].sensor_type == 0 && sen[j + 1].sensor_type == 1) {
				ok = 0;
				sensor aux;
				aux = sen[j];
				sen[j] = sen[j + 1];
				sen[j + 1] = aux;
			}
		}
	}
}

void Print(char com[100], sensor *sen, int nr)
{
	/*se parcurge stringul pana la cifra
	si ea se atribuie lui variabilei c de tip char*/
	char *p;
	p = strtok(com, " ");
	p = strtok(0, " ");

	/*se utilizeaza functia predefinita atoi
	care converteste litere in cifre*/
	int i = atoi(p);

	/*se verifica daca senzorului cautat de comanda exista*/
	if (i < 0 || i > nr) {
		printf("Index not in range!\n");
	} else {

		/*se testeaza de ce tip este senzorul, iar in functie de tipul sau
		se afiseaza informatiile structurii respective*/
		if (sen[i].sensor_type == PMU) {

			/* se atribuie unei noi variabile de power_management_unit
			castul facut la acest tip de date al lui sensor_data*/
			power_management_unit *pmu2;
			pmu2 = (power_management_unit *)sen[i].sensor_data;
			printf("Power Management Unit\n");
			printf("Voltage: %.2f\n", pmu2->voltage);
			printf("Current: %.2f\n", pmu2->current);
			printf("Power Consumption: %.2f\n", pmu2->power_consumption);
			printf("Energy Regen: %d%c\n", pmu2->energy_regen, '%');
			printf("Energy Storage: %d%c\n", pmu2->energy_storage, '%');
		}

		if (sen[i].sensor_type == TIRE) {

			/* se atribuie unei noi variabile de tire_sensor
			 castul facut la acest tip de date al lui sensor_data*/
			tire_sensor *tire2 = (tire_sensor *)sen[i].sensor_data;
			printf("Tire Sensor\n");
			printf("Pressure: %.2f\n", tire2->pressure);
			printf("Temperature: %.2f\n", tire2->temperature);
			printf("Wear Level: %d%c\n", tire2->wear_level, '%');

			/*daca performance scor nu este calculat
			 se afiseaza un mesaj, altfel valoarea respectiva*/
			if (tire2->performace_score != 0)
				printf("Performance Score: %d\n", tire2->performace_score);
			else
				printf("Performance Score: Not Calculated\n");
		}
	}
}

void Analyze(char com[100], sensor *sen, int nr, void (*vect[8])(void *))
{
	/*se parcurge stringul pana la cifra
	si ea se atribuie lui variabilei c de tip char*/
	char *c;
	c = strtok(com, " ");
	c = strtok(0, " ");

	/*se utilizeaza functia predefinita atoi care
	converteste litere in cifre*/
	int i = atoi(c);

	/*se verifica daca senzorului
	cautat de comanda exista*/
	if (i < 0 || i >= nr) {
		printf("Index not in range!\n");
	} else {
		/*se apeleaza functiile prin intermediul
		vectorului, informatiile date ca parametru de
		tip void* fiind sen[i].sensor_data*/
		for (int j = 0; j < sen[i].nr_operations; j++)
			vect[sen[i].operations_idxs[j]](sen[i].sensor_data);
	}
}

void Clear(sensor *sen, int *nr)
{
	for (int i = 0; i < (*nr); i++) {

		/*se presupune ca senzorul are date corecte*/
		int ok = 1;
		if (sen[i].sensor_type == 0) {
			/*se face cast datelor senzorului la tipul
			 de senzor TIRE si se verifica*/
			tire_sensor *tire2;
			tire2 = (tire_sensor *)sen[i].sensor_data;
			if (tire2->pressure < 19 || tire2->pressure > 28 ||
				tire2->temperature < 0 || tire2->temperature > 120 ||
				tire2->wear_level < 0 || tire2->wear_level > 100) {

				/*se retine varibila pe care vrem sa o stergem*/
				sensor deretinut = sen[i];

				/*se sterge senzorul din vector si se tine minte ca
				s-a sters un senzor prin variabila ok*/
				for (int j = i; j <= (*nr) - 2; j++)
					sen[j] = sen[j + 1];

				/*senzorul pe care vrem sa il
				stergem il mutam la final*/
				sen[(*nr) - 1] = deretinut;
				ok = 0;
			}
		}

		if (sen[i].sensor_type == 1) {

			/*se face cast datelor senzorului la tipul
			 de senzor PMU si se verifica*/
			power_management_unit *pmu2;
			pmu2 = (power_management_unit *)sen[i].sensor_data;

			if (pmu2->voltage < 10 || pmu2->voltage > 20 ||
				pmu2->current < (-100) || pmu2->current > 100 ||
				pmu2->power_consumption < 0 || pmu2->power_consumption > 1000 ||
				pmu2->energy_regen < 0 || pmu2->energy_regen > 100 ||
				pmu2->energy_storage < 0 || pmu2->energy_storage > 100) {

				/*se retine varibila pe care vrem sa o stergem*/
				sensor deretinut = sen[i];

				/*se sterge senzorul din vector si se tine minte ca
				s-a sters un senzor prin variabila ok*/
				for (int j = i; j <= (*nr) - 2; j++)
					sen[j] = sen[j + 1];

				/*senzorul pe care vrem sa il
				stergem il mutam la final*/
				sen[(*nr) - 1] = deretinut;
				ok = 0;
			}
		}

/*daca un senzor a fost sters se bate pasul pe loc, se micsoreaza
lungimea vectorului de senzori*/

		if (ok == 0) {
			/*dezalocam memoria pentru
			senzorul incorect de la final*/
			sensor aux = sen[(*nr) - 1];
			free(aux.sensor_data);
			free(aux.operations_idxs);
			(*nr) = (*nr) - 1;
			i = i - 1;
		}
	}
}

int main(int argc, char const *argv[])
{
	/*se deschide fisierul binar si se testeaza actiunea efectuata*/
	FILE *fin = fopen(argv[1], "rb");
	if (!fin)
		return 0;

	/*se citeste numarul de senzori*/
	int nr = 0, ok = 0;
	fread(&nr, sizeof(int), 1, fin);

	/*se aloca dinamic memorie pentru
	vectorul de senzori si se verifica actiunea*/
	sensor *sen = (sensor *)malloc(nr * sizeof(sensor));
	if (!sen)
		return 0;
	Citire(sen, nr, fin);
	SortarePrioritati(sen, nr, ok);

	/*se preiau operatiile prin intermediul
	functiei date in vetorul de tip void* */
	void *op[8];
	get_operations(op);

	/*se ia un vector de pointeri prin intermediul caruia
	se vor apela functiile cu parametrii de tip void* */
	void (*vect[8])(void *);

	/*i se atribuie vectorului operatiile
	preluate prin intermediul functiei get_operations*/
	for (int j = 0; j < 8; j++)
		vect[j] = op[j];

	/*se citeste de la tastatura prima comanda*/
	char com[100];
	fgets(com, sizeof(com), stdin);

	/*se citesc stringuri de la tastatura pana
	cand se intalneste comanda de iesire - exit*/
	while (strcmp(com, "exit\n")) {

		/*daca primele 5 caractere ale comenzii citite sunt identice cu
		stringul print se realizeaza comanda print*/
		if (strncmp(com, "print", 5) == 0)
			Print(com, sen, nr);

		/*daca primele 7 caractere ale comenzii citite sunt identice cu
		stringul analyze se realizeaza analyze*/
		if (strncmp(com, "analyze", 7) == 0)
			Analyze(com, sen, nr, vect);

		/*daca primele 5 caractere ale comenzii citite sunt identice cu
		stringul clear se realizeaza clear*/
		if (strncmp(com, "clear", 5) == 0)
			Clear(sen, &nr);

		/*se citeste un nou string de la tastatura*/
		fgets(com, sizeof(com), stdin);
	}

	/*se elibereaza memoria alocata
	pentru datele senzorului si pentru operatii*/
	for (int i = 0; i < nr; i++) {
		free(sen[i].sensor_data);
		free(sen[i].operations_idxs);
	}

	/*se elibereaza si memoria alocata vectorului de senzori*/
	free(sen);

	/*se inchide fisierul binar deschid*/
	fclose(fin);
	return 0;
}

